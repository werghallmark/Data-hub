using System.IO.Compression;
using System.Text;

namespace QuantDesk.DataHub.Common.Util;

/// <summary>
/// Append-only gzip JSONL writer with UTC-hour rotation.
/// Path pattern: {base}\raw\{exchange}\{market}\{symbol}\YYYY\MM\DD\HH\raw.jsonl.gz
/// </summary>
public sealed class GzipJsonlWriter : IDisposable
{
    private readonly string _baseDir;
    private readonly object _lock = new();
    private FileStream? _fs;
    private GZipStream? _gz;
    private StreamWriter? _sw;
    private DateTime _openHourUtc = DateTime.MinValue;

    public GzipJsonlWriter(string baseDir)
    {
        _baseDir = baseDir;
    }

    public void AppendLineUtc(DateTime utcNow, string jsonLine)
    {
        lock (_lock)
        {
            EnsureOpen(utcNow);
            _sw!.WriteLine(jsonLine);
            _sw.Flush(); // durability > throughput, per "lossless" requirement
        }
    }

    private void EnsureOpen(DateTime utcNow)
    {
        var hour = new DateTime(utcNow.Year, utcNow.Month, utcNow.Day, utcNow.Hour, 0, 0, DateTimeKind.Utc);
        if (_fs != null && hour == _openHourUtc) return;

        DisposeStreams();

        _openHourUtc = hour;

        var dir = Path.Combine(_baseDir,
            utcNow.Year.ToString("D4"),
            utcNow.Month.ToString("D2"),
            utcNow.Day.ToString("D2"),
            utcNow.Hour.ToString("D2"));
        Directory.CreateDirectory(dir);

        var path = Path.Combine(dir, "raw.jsonl.gz");
        _fs = new FileStream(path, FileMode.Append, FileAccess.Write, FileShare.Read);
        _gz = new GZipStream(_fs, CompressionLevel.Fastest, leaveOpen: false);
        _sw = new StreamWriter(_gz, new UTF8Encoding(encoderShouldEmitUTF8Identifier: false));
    }

    private void DisposeStreams()
    {
        try { _sw?.Dispose(); } catch { }
        try { _gz?.Dispose(); } catch { }
        try { _fs?.Dispose(); } catch { }
        _sw = null;
        _gz = null;
        _fs = null;
    }

    public void Dispose()
    {
        lock (_lock)
        {
            DisposeStreams();
        }
    }
}
