using System.Text;
using System.Text.Json;

namespace QuantDesk.DataHub.Common.Util;

public static class ErrorLedger
{
    private static readonly object _lock = new();

    public static void Append(string component, Exception ex, string? basePath = null)
    {
        try
        {
            basePath ??= Environment.GetEnvironmentVariable("DATAHUB_BASE") ?? @"C:\DataHub";
            Directory.CreateDirectory(basePath);
            var path = Path.Combine(basePath, "errors.jsonl");

            var evt = new
            {
                tsUtc = DateTime.UtcNow.ToString("O"),
                component,
                type = ex.GetType().FullName,
                message = ex.Message,
                stack = ex.ToString()
            };

            var line = JsonSerializer.Serialize(evt);
            lock (_lock)
            {
                File.AppendAllText(path, line + "\n", Encoding.UTF8);
            }
        }
        catch
        {
            // swallow: last resort logger
        }
    }

    public static IEnumerable<string> Tail(string basePath, int n)
    {
        var path = Path.Combine(basePath, "errors.jsonl");
        if (!File.Exists(path)) return Array.Empty<string>();
        var lines = File.ReadLines(path);
        return lines.Reverse().Take(n).Reverse();
    }
}
