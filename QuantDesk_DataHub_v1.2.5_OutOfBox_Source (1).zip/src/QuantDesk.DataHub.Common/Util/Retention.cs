namespace QuantDesk.DataHub.Common.Util;

public static class Retention
{
    public static void EnforceUtcDays(string rootDir, int keepDays)
    {
        if (!Directory.Exists(rootDir)) return;
        var cutoff = DateTime.UtcNow.Date.AddDays(-keepDays);

        foreach (var yyyyDir in SafeEnumDirs(rootDir))
        {
            if (!int.TryParse(Path.GetFileName(yyyyDir), out var yyyy)) continue;
            foreach (var mmDir in SafeEnumDirs(yyyyDir))
            {
                if (!int.TryParse(Path.GetFileName(mmDir), out var mm)) continue;
                foreach (var ddDir in SafeEnumDirs(mmDir))
                {
                    if (!int.TryParse(Path.GetFileName(ddDir), out var dd)) continue;

                    DateTime day;
                    try { day = new DateTime(yyyy, mm, dd, 0, 0, 0, DateTimeKind.Utc); }
                    catch { continue; }

                    if (day < cutoff)
                    {
                        try { Directory.Delete(ddDir, recursive: true); }
                        catch { /* ignore */ }
                    }
                }
            }
        }
    }

    private static IEnumerable<string> SafeEnumDirs(string dir)
    {
        try { return Directory.EnumerateDirectories(dir); }
        catch { return Array.Empty<string>(); }
    }
}
