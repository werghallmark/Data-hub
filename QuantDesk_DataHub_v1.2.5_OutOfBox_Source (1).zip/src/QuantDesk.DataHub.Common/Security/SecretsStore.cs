using System.Text.Json;
using System.Text.Json.Serialization;

namespace QuantDesk.DataHub.Common.Security;

public sealed class Secrets
{
    public string PasswordHashB64 { get; init; }
    public string PasswordSaltB64 { get; init; }
    public int Iterations { get; init; }
}

public static class SecretsStore
{
    public static string SecretsPath(string basePath) => Path.Combine(basePath, "secrets.json");

    public static Secrets LoadOrThrow(string basePath)
    {
        var path = SecretsPath(basePath);
        if (!File.Exists(path))
            throw new FileNotFoundException("secrets.json not found. Run installer.", path);

        var json = File.ReadAllText(path);
        return JsonSerializer.Deserialize<Secrets>(json, JsonOpts())
            ?? throw new InvalidOperationException("Failed to parse secrets.json");
    }

    public static void Save(string basePath, Secrets secrets)
    {
        Directory.CreateDirectory(basePath);
        var json = JsonSerializer.Serialize(secrets, JsonOpts(true));
        File.WriteAllText(SecretsPath(basePath), json);
    }

    private static JsonSerializerOptions JsonOpts(bool writeIndented = false) => new()
    {
        PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
        WriteIndented = writeIndented,
        DefaultIgnoreCondition = JsonIgnoreCondition.Never
    };
}
