namespace QuantDesk.DataHub.Common.Config;

public sealed class AppConfig
{
    public string BasePath { get; init; } = @"C:\DataHub";
    public string Exchange { get; init; } = "mexc";
    public string Market { get; set; } = "futures"; // futures|spot
    public string Symbol { get; set; } = "BTC_USDT"; // futures uses underscore; spot uses BTCUSDT
    public string BindIp { get; set; } = "127.0.0.1"; // installer sets tailscale 100.x
    public int MainPort { get; init; } = 8000;
    public int FramePort { get; init; } = 8010;

    public int FrameIntervalMs { get; init; } = 200;
    public int RetentionDays { get; init; } = 30;

    public string FuturesRestBaseUrl { get; set; } = "https://api.mexc.com"; // new futures API domain
    public string FuturesWsUrl { get; set; } = "wss://contract.mexc.com/edge";

    public string SpotRestBaseUrl { get; set; } = "https://api.mexc.com";
    public string SpotWsUrl { get; set; } = "wss://wbs-api.mexc.com/ws";

    // Spot favorites list (editable); futures list is fetched dynamically at runtime.
    public List<string> SpotFavorites { get; set; } = new() { "BTCUSDT", "ETHUSDT", "FLOKIUSDT" };

    // Internal maintenance settings
    public int WsPingSeconds { get; set; } = 15;
    public int ReconnectBackoffMs { get; set; } = 2000;
    public int MaxRawWriteQueue { get; set; } = 20000; // backpressure protection
    public int MaxBookLevelsInFrame { get; set; } = 4000;
    public string DailyCollectorRestartUtc { get; set; } = "04:00"; // HH:mm UTC
}
