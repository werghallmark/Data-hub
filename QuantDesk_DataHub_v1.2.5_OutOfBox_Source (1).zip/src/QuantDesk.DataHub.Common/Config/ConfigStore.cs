using System.Text.Json;
using System.Text.Json.Serialization;

namespace QuantDesk.DataHub.Common.Config;

public static class ConfigStore
{
    public static string ConfigPath(string basePath) => Path.Combine(basePath, "config.json");

    public static AppConfig LoadOrCreateDefault(string basePath)
    {
        Directory.CreateDirectory(basePath);
        var path = ConfigPath(basePath);
        if (!File.Exists(path))
        {
            var cfg = new AppConfig { BasePath = basePath };
            Save(cfg);
            return cfg;
        }

        var json = File.ReadAllText(path);
        var cfgLoaded = JsonSerializer.Deserialize<AppConfig>(json, JsonOpts())
            ?? throw new InvalidOperationException("Failed to parse config.json");
        return cfgLoaded;
    }

    public static AppConfig LoadOrThrow()
    {
        var basePath = Environment.GetEnvironmentVariable("DATAHUB_BASE") ?? @"C:\DataHub";
        var path = ConfigPath(basePath);
        if (!File.Exists(path))
            throw new FileNotFoundException("config.json not found. Run installer or create config first.", path);

        var json = File.ReadAllText(path);
        return JsonSerializer.Deserialize<AppConfig>(json, JsonOpts())
            ?? throw new InvalidOperationException("Failed to parse config.json");
    }

    public static void Save(AppConfig cfg)
    {
        Directory.CreateDirectory(cfg.BasePath);
        var json = JsonSerializer.Serialize(cfg, JsonOpts(true));
        File.WriteAllText(ConfigPath(cfg.BasePath), json);
    }

    private static JsonSerializerOptions JsonOpts(bool writeIndented = false) => new()
    {
        PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
        WriteIndented = writeIndented,
        DefaultIgnoreCondition = JsonIgnoreCondition.Never
    };
}
