using System.Windows;

namespace QuantDesk.DataHub.ControlPanel;

public partial class App : Application
{
}
