using System.Diagnostics;
using System.Windows;
using QuantDesk.DataHub.Common.Config;
using QuantDesk.DataHub.Common.Security;

namespace QuantDesk.DataHub.ControlPanel;

public partial class MainWindow : Window
{
    private readonly AppConfig _cfg;

    public MainWindow()
    {
        InitializeComponent();

        var basePath = Environment.GetEnvironmentVariable("DATAHUB_BASE") ?? @"C:\DataHub";
        _cfg = ConfigStore.LoadOrCreateDefault(basePath);

        if (!PromptPassword(basePath))
        {
            Close();
            return;
        }

        var web = $"http://{_cfg.BindIp}:{_cfg.MainPort}/ui";
        var frame = $"http://{_cfg.BindIp}:{_cfg.FramePort}/frame/latest";
        UrlsText.Text = $"Web Control: {web}\nFrame API: {frame}\nBase path: {_cfg.BasePath}";
    }

    private static bool PromptPassword(string basePath)
    {
        var secrets = SecretsStore.LoadOrThrow(basePath);

        var dlg = new PasswordDialog();
        if (dlg.ShowDialog() != true) return false;

        var ok = PasswordHasher.Verify(dlg.PasswordValue, secrets.PasswordHashB64, secrets.PasswordSaltB64, secrets.Iterations);
        if (!ok)
        {
            MessageBox.Show("Invalid password.", "DataHub", MessageBoxButton.OK, MessageBoxImage.Error);
            return false;
        }
        return true;
    }

    private void OpenWeb_Click(object sender, RoutedEventArgs e)
        => Process.Start(new ProcessStartInfo { FileName = $"http://{_cfg.BindIp}:{_cfg.MainPort}/ui", UseShellExecute = true });

    private void OpenFrame_Click(object sender, RoutedEventArgs e)
        => Process.Start(new ProcessStartInfo { FileName = $"http://{_cfg.BindIp}:{_cfg.FramePort}/frame/latest", UseShellExecute = true });

    private void OpenFolder_Click(object sender, RoutedEventArgs e)
        => Process.Start(new ProcessStartInfo { FileName = _cfg.BasePath, UseShellExecute = true });
}
