using System.Windows;

namespace QuantDesk.DataHub.ControlPanel;

public partial class PasswordDialog : Window
{
    public string PasswordValue { get; private set; } = "";

    public PasswordDialog()
    {
        InitializeComponent();
        Pw.Focus();
    }

    private void Ok_Click(object sender, RoutedEventArgs e)
    {
        PasswordValue = Pw.Password ?? "";
        DialogResult = true;
    }

    private void Cancel_Click(object sender, RoutedEventArgs e)
    {
        DialogResult = false;
    }
}
