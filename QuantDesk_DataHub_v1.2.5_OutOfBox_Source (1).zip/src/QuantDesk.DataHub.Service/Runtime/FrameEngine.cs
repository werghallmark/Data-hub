using System.Text.Json;
using Microsoft.Extensions.Logging;
using QuantDesk.DataHub.Common.Config;
using QuantDesk.DataHub.Common.Util;

namespace QuantDesk.DataHub.Service.Runtime;

public sealed class FrameEngine
{
    private readonly ILogger<FrameEngine> _log;
    private readonly AppConfig _cfg;
    private readonly DataHubState _state;
    private readonly IBookSource _book;

    private readonly GzipJsonlWriter _frameWriter;

    public FrameEngine(ILogger<FrameEngine> log, AppConfig cfg, DataHubState state, IBookSource book)
    {
        _log = log;
        _cfg = cfg;
        _state = state;
        _book = book;

        var framesBase = Path.Combine(cfg.BasePath, "frames", cfg.Exchange, cfg.Market, cfg.Symbol);
        _frameWriter = new GzipJsonlWriter(framesBase);
    }

    public Task StartAsync(CancellationToken ct)
    {
        _ = Task.Run(() => Loop(ct), ct);
        return Task.CompletedTask;
    }

    private async Task Loop(CancellationToken ct)
    {
        var interval = TimeSpan.FromMilliseconds(_cfg.FrameIntervalMs);

        // align to wallclock boundaries for deterministic cadence
        while (!ct.IsCancellationRequested)
        {
            var start = DateTime.UtcNow;
            try
            {
                var (bids, asks, version) = _book.Snapshot();
                var frame = BuildFrame(start, bids, asks, version);

                var json = JsonSerializer.Serialize(frame);
                _frameWriter.AppendLineUtc(start, json);
                _state.LastFrameJson = json;
                _state.LastFrameUtc = start;
                _state.IncFramesWritten();
            }
            catch (Exception ex)
            {
                ErrorLedger.Append("frame_engine", ex, _cfg.BasePath);
            }

            var elapsed = DateTime.UtcNow - start;
            var delay = interval - elapsed;
            if (delay < TimeSpan.Zero) delay = TimeSpan.Zero;
            await Task.Delay(delay, ct);
        }
    }

    private object BuildFrame(DateTime tsUtc, IReadOnlyDictionary<double, double> bids, IReadOnlyDictionary<double, double> asks, long version)
    {
        // Deterministic ordering: bids desc, asks asc.
        var bidList = bids.OrderByDescending(kv => kv.Key).Take(_cfg.MaxBookLevelsInFrame)
            .Select(kv => new[] { kv.Key, kv.Value }).ToArray();
        var askList = asks.OrderBy(kv => kv.Key).Take(_cfg.MaxBookLevelsInFrame)
            .Select(kv => new[] { kv.Key, kv.Value }).ToArray();

        return new
        {
            tsUtc = tsUtc.ToString("O"),
            exchange = _cfg.Exchange,
            market = _cfg.Market,
            symbol = _cfg.Symbol,
            version,
            bids = bidList,
            asks = askList
        };
    }
}
