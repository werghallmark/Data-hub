using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using QuantDesk.DataHub.Common.Config;
using QuantDesk.DataHub.Common.Util;
using QuantDesk.DataHub.Service.Connectors;

namespace QuantDesk.DataHub.Service.Runtime;

public sealed class DataHubHostedService : BackgroundService
{
    private readonly ILogger<DataHubHostedService> _log;
    private readonly AppConfig _cfg;
    private readonly ICollector _collector;
    private readonly FrameEngine _frameEngine;
    private readonly RetentionService _retention;
    private readonly DailyRestartService _dailyRestart;

    public DataHubHostedService(
        ILogger<DataHubHostedService> log,
        AppConfig cfg,
        ICollector collector,
        FrameEngine frameEngine,
        RetentionService retention,
        DailyRestartService dailyRestart)
    {
        _log = log;
        _cfg = cfg;
        _collector = collector;
        _frameEngine = frameEngine;
        _retention = retention;
        _dailyRestart = dailyRestart;
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        try
        {
            _log.LogInformation("DataHub starting. Base={base} Market={market} Symbol={symbol}", _cfg.BasePath, _cfg.Market, _cfg.Symbol);
            await _collector.StartAsync(stoppingToken);
            await _frameEngine.StartAsync(stoppingToken);
            await _retention.StartAsync(stoppingToken);
            await _dailyRestart.StartAsync(stoppingToken, _collector);
        }
        catch (Exception ex)
        {
            ErrorLedger.Append("hosted_service", ex, _cfg.BasePath);
            throw;
        }

        // Keep alive
        while (!stoppingToken.IsCancellationRequested)
        {
            await Task.Delay(1000, stoppingToken);
        }
    }
}
