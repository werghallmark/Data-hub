using Microsoft.Extensions.Logging;
using QuantDesk.DataHub.Common.Config;
using QuantDesk.DataHub.Common.Util;
using QuantDesk.DataHub.Service.Connectors;

namespace QuantDesk.DataHub.Service.Runtime;

public sealed class DailyRestartService
{
    private readonly ILogger<DailyRestartService> _log;
    private readonly AppConfig _cfg;
    private DateTime _lastRunDayUtc = DateTime.MinValue;

    public DailyRestartService(ILogger<DailyRestartService> log, AppConfig cfg)
    {
        _log = log;
        _cfg = cfg;
    }

    public Task StartAsync(CancellationToken ct, ICollector collector)
    {
        _ = Task.Run(() => Loop(ct, collector), ct);
        return Task.CompletedTask;
    }

    private async Task Loop(CancellationToken ct, ICollector collector)
    {
        while (!ct.IsCancellationRequested)
        {
            try
            {
                var now = DateTime.UtcNow;
                if (!TimeOnly.TryParse(_cfg.DailyCollectorRestartUtc, out var t))
                    t = new TimeOnly(4, 0);

                var scheduled = new DateTime(now.Year, now.Month, now.Day, t.Hour, t.Minute, 0, DateTimeKind.Utc);

                if (now >= scheduled && _lastRunDayUtc.Date != now.Date)
                {
                    _lastRunDayUtc = now.Date;
                    _log.LogWarning("Daily restart window reached (UTC {time}). Restarting collector.", _cfg.DailyCollectorRestartUtc);
                    await collector.RestartAsync(ct);
                }
            }
            catch (Exception ex)
            {
                ErrorLedger.Append("daily_restart", ex, _cfg.BasePath);
            }

            await Task.Delay(TimeSpan.FromSeconds(10), ct);
        }
    }
}
