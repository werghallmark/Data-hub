using System.Collections.Concurrent;
using System.Threading;

namespace QuantDesk.DataHub.Service.Runtime;

/// <summary>
/// Thread-safe state snapshot for Control Panel and Web Control.
/// Uses atomic/volatile primitives instead of 'volatile' on unsupported types.
/// </summary>
public sealed class DataHubState
{
    private int _collectorRunning; // 0/1
    private string _collectorStatus = "stopped";

    private long _lastDepthUtcTicks = DateTime.MinValue.Ticks;
    private long _lastTradeUtcTicks = DateTime.MinValue.Ticks;
    private long _lastFrameUtcTicks = DateTime.MinValue.Ticks;

    private long _lastDepthVersion = -1;
    private long _depthUpdates;
    private long _trades;
    private long _framesWritten;

    private string _lastFrameJson = "";

    public bool CollectorRunning
    {
        get => Volatile.Read(ref _collectorRunning) == 1;
        set => Volatile.Write(ref _collectorRunning, value ? 1 : 0);
    }

    public string CollectorStatus
    {
        get => Volatile.Read(ref _collectorStatus);
        set => Volatile.Write(ref _collectorStatus, value ?? "");
    }

    public DateTime LastDepthUtc
    {
        get => DateTime.SpecifyKind(new DateTime(Interlocked.Read(ref _lastDepthUtcTicks)), DateTimeKind.Utc);
        set => Interlocked.Exchange(ref _lastDepthUtcTicks, value.ToUniversalTime().Ticks);
    }

    public DateTime LastTradeUtc
    {
        get => DateTime.SpecifyKind(new DateTime(Interlocked.Read(ref _lastTradeUtcTicks)), DateTimeKind.Utc);
        set => Interlocked.Exchange(ref _lastTradeUtcTicks, value.ToUniversalTime().Ticks);
    }

    public DateTime LastFrameUtc
    {
        get => DateTime.SpecifyKind(new DateTime(Interlocked.Read(ref _lastFrameUtcTicks)), DateTimeKind.Utc);
        set => Interlocked.Exchange(ref _lastFrameUtcTicks, value.ToUniversalTime().Ticks);
    }

    public long LastDepthVersion
    {
        get => Interlocked.Read(ref _lastDepthVersion);
        set => Interlocked.Exchange(ref _lastDepthVersion, value);
    }

    public long DepthUpdates => Interlocked.Read(ref _depthUpdates);
    public long Trades => Interlocked.Read(ref _trades);
    public long FramesWritten => Interlocked.Read(ref _framesWritten);

    public string LastFrameJson
    {
        get => Volatile.Read(ref _lastFrameJson);
        set => Volatile.Write(ref _lastFrameJson, value ?? "");
    }

    public void IncDepthUpdates() => Interlocked.Increment(ref _depthUpdates);
    public void IncTrades() => Interlocked.Increment(ref _trades);
    public void IncFramesWritten() => Interlocked.Increment(ref _framesWritten);

    public void AddDepthUpdates(long n)
    {
        if (n <= 0) return;
        Interlocked.Add(ref _depthUpdates, n);
    }

    public void AddTrades(long n)
    {
        if (n <= 0) return;
        Interlocked.Add(ref _trades, n);
    }

    public ConcurrentQueue<string> RecentEvents { get; } = new(); // small ring
}
