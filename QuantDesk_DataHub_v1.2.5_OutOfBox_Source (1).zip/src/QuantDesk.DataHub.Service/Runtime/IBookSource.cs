namespace QuantDesk.DataHub.Service.Runtime;

public interface IBookSource
{
    (IReadOnlyDictionary<double, double> bids, IReadOnlyDictionary<double, double> asks, long version) Snapshot();
}
