using Microsoft.Extensions.Logging;
using QuantDesk.DataHub.Common.Config;
using QuantDesk.DataHub.Common.Util;

namespace QuantDesk.DataHub.Service.Runtime;

public sealed class RetentionService
{
    private readonly ILogger<RetentionService> _log;
    private readonly AppConfig _cfg;

    public RetentionService(ILogger<RetentionService> log, AppConfig cfg)
    {
        _log = log;
        _cfg = cfg;
    }

    public Task StartAsync(CancellationToken ct)
    {
        _ = Task.Run(() => Loop(ct), ct);
        return Task.CompletedTask;
    }

    private async Task Loop(CancellationToken ct)
    {
        while (!ct.IsCancellationRequested)
        {
            try
            {
                var rawRoot = Path.Combine(_cfg.BasePath, "raw", _cfg.Exchange);
                var framesRoot = Path.Combine(_cfg.BasePath, "frames", _cfg.Exchange);

                Retention.EnforceUtcDays(rawRoot, _cfg.RetentionDays);
                Retention.EnforceUtcDays(framesRoot, _cfg.RetentionDays);

                _log.LogInformation("Retention enforced: keepDays={d}", _cfg.RetentionDays);
            }
            catch (Exception ex)
            {
                ErrorLedger.Append("retention", ex, _cfg.BasePath);
            }

            await Task.Delay(TimeSpan.FromHours(1), ct);
        }
    }
}
