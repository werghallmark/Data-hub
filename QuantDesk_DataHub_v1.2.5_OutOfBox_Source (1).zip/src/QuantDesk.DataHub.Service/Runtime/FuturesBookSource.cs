using QuantDesk.DataHub.Service.Connectors;

namespace QuantDesk.DataHub.Service.Runtime;

public sealed class FuturesBookSource : IBookSource
{
    private readonly MexcFuturesCollector _collector;

    public FuturesBookSource(MexcFuturesCollector collector)
    {
        _collector = collector;
    }

    public (IReadOnlyDictionary<double, double> bids, IReadOnlyDictionary<double, double> asks, long version) Snapshot()
    {
        var snap = _collector.SnapshotBook();
        return (snap.bids, snap.asks, snap.version);
    }
}
