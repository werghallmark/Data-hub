namespace QuantDesk.DataHub.Service.Connectors;

public interface ICollector
{
    string Name { get; }
    Task StartAsync(CancellationToken ct);
    Task StopAsync();
    Task RestartAsync(CancellationToken ct);
}
