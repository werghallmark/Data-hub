using System.Net.Http.Json;
using System.Net.WebSockets;
using System.Text;
using System.Text.Json;
using Microsoft.Extensions.Logging;
using QuantDesk.DataHub.Common.Config;
using QuantDesk.DataHub.Common.Util;
using QuantDesk.DataHub.Service.Runtime;

namespace QuantDesk.DataHub.Service.Connectors;

public sealed class MexcFuturesCollector : ICollector
{
    public string Name => "mexc-futures";

    private readonly ILogger<MexcFuturesCollector> _log;
    private readonly AppConfig _cfg;
    private readonly DataHubState _state;

    private readonly HttpClient _http = new();
    private ClientWebSocket? _ws;
    private CancellationTokenSource? _runCts;
    private Task? _runTask;

    private readonly Dictionary<double, double> _bids = new(); // price -> qty
    private readonly Dictionary<double, double> _asks = new();

    // version continuity (per MEXC incremental maintenance mechanism)
    private long _lastEventVersion = -1;

    private readonly GzipJsonlWriter _rawWriter;
    private readonly object _bookLock = new();

    public MexcFuturesCollector(ILogger<MexcFuturesCollector> log, AppConfig cfg, DataHubState state)
    {
        _log = log;
        _cfg = cfg;
        _state = state;

        var rawBase = Path.Combine(cfg.BasePath, "raw", cfg.Exchange, "futures", cfg.Symbol);
        _rawWriter = new GzipJsonlWriter(rawBase);
    }

    public Task StartAsync(CancellationToken ct)
    {
        if (_runTask != null && !_runTask.IsCompleted) return Task.CompletedTask;
        _runCts = CancellationTokenSource.CreateLinkedTokenSource(ct);
        _runTask = Task.Run(() => RunLoop(_runCts.Token), _runCts.Token);
        return Task.CompletedTask;
    }

    public async Task StopAsync()
    {
        try { _runCts?.Cancel(); } catch { }
        if (_runTask != null)
        {
            try { await _runTask; } catch { }
        }
        try { _ws?.Abort(); _ws?.Dispose(); } catch { }
        _ws = null;
        _runTask = null;
        _runCts = null;
    }

    public async Task RestartAsync(CancellationToken ct)
    {
        await StopAsync();
        await Task.Delay(250, ct);
        await StartAsync(ct);
    }

    private async Task RunLoop(CancellationToken ct)
    {
        _state.CollectorRunning = true;
        _state.CollectorStatus = "starting";

        while (!ct.IsCancellationRequested)
        {
            try
            {
                _state.CollectorStatus = "syncing-snapshot";
                await SyncSnapshotAndCommits(ct);

                _state.CollectorStatus = "connecting-ws";
                _ws = new ClientWebSocket();
                await _ws.ConnectAsync(new Uri(_cfg.FuturesWsUrl), ct);
                _log.LogInformation("Connected WS {url}", _cfg.FuturesWsUrl);

                // subscribe: depth + trades (deal)
                await SendJsonAsync(new { method = "sub.depth", param = new { symbol = _cfg.Symbol } }, ct);
                await SendJsonAsync(new { method = "sub.deal", param = new { symbol = _cfg.Symbol } }, ct);

                var pingTask = Task.Run(() => PingLoop(ct), ct);

                _state.CollectorStatus = "running";
                await ReceiveLoop(ct);

                try { await pingTask; } catch { }
            }
            catch (OperationCanceledException) when (ct.IsCancellationRequested) { }
            catch (Exception ex)
            {
                ErrorLedger.Append("mexc_futures", ex, _cfg.BasePath);
                _log.LogWarning(ex, "Futures collector error. Reconnecting in {ms}ms", _cfg.ReconnectBackoffMs);
                _state.CollectorStatus = "error-reconnecting";
                await Task.Delay(_cfg.ReconnectBackoffMs, ct);
            }
            finally
            {
                try { _ws?.Abort(); _ws?.Dispose(); } catch { }
                _ws = null;
            }
        }

        _state.CollectorRunning = false;
        _state.CollectorStatus = "stopped";
    }

    private async Task PingLoop(CancellationToken ct)
    {
        while (!ct.IsCancellationRequested && _ws != null && _ws.State == WebSocketState.Open)
        {
            await SendJsonAsync(new { method = "ping" }, ct);
            await Task.Delay(TimeSpan.FromSeconds(_cfg.WsPingSeconds), ct);
        }
    }

    private async Task ReceiveLoop(CancellationToken ct)
    {
        if (_ws == null) return;

        var buf = new byte[1 << 20]; // 1MB
        while (!ct.IsCancellationRequested && _ws.State == WebSocketState.Open)
        {
            using var ms = new MemoryStream();
            WebSocketReceiveResult? res;
            do
            {
                res = await _ws.ReceiveAsync(buf, ct);
                if (res.MessageType == WebSocketMessageType.Close)
                {
                    _log.LogWarning("WS closed by server.");
                    await _ws.CloseAsync(WebSocketCloseStatus.NormalClosure, "closing", ct);
                    return;
                }
                ms.Write(buf, 0, res.Count);
            } while (!res.EndOfMessage);

            var msg = Encoding.UTF8.GetString(ms.ToArray());
            WriteRaw(msg);

            try { HandleMessage(msg); }
            catch (Exception ex)
            {
                ErrorLedger.Append("mexc_futures.handle", ex, _cfg.BasePath);
            }
        }
    }

    private void WriteRaw(string msg)
    {
        var evt = new
        {
            tsUtc = DateTime.UtcNow.ToString("O"),
            exchange = _cfg.Exchange,
            market = "futures",
            symbol = _cfg.Symbol,
            msg
        };
        _rawWriter.AppendLineUtc(DateTime.UtcNow, JsonSerializer.Serialize(evt));
    }

    private void HandleMessage(string msg)
    {
        using var doc = JsonDocument.Parse(msg);
        var root = doc.RootElement;

        // pong
        if (root.TryGetProperty("channel", out var ch) && ch.GetString() == "pong") return;

        if (root.TryGetProperty("channel", out var channelProp))
        {
            var channel = channelProp.GetString() ?? "";
            if (channel == "push.deal")
            {
                _state.AddTrades(CountArray(root, "data"));
                _state.LastTradeUtc = DateTime.UtcNow;
                return;
            }
            if (channel == "push.depth")
            {
                ApplyDepth(root);
                return;
            }
        }
    }

    private static int CountArray(JsonElement root, string prop)
    {
        if (!root.TryGetProperty(prop, out var el)) return 0;
        if (el.ValueKind != JsonValueKind.Array) return 0;
        return el.GetArrayLength();
    }

    private void ApplyDepth(JsonElement root)
    {
        if (!root.TryGetProperty("data", out var data)) return;
        if (!data.TryGetProperty("version", out var vEl) || vEl.ValueKind != JsonValueKind.Number) return;
        var version = vEl.GetInt64();

        // MEXC incremental maintenance mechanism requires version continuity: new == prev + 1; else resync with commits. (docs)
        if (_lastEventVersion != -1 && version != _lastEventVersion + 1)
        {
            _log.LogWarning("Version gap detected: got {v} expected {exp}. Resync.", version, _lastEventVersion + 1);
            _state.CollectorStatus = "resyncing-gap";
            // best-effort resync inline (blocking)
            SyncSnapshotAndCommits(CancellationToken.None).GetAwaiter().GetResult();
        }

        lock (_bookLock)
        {
            ApplySide(_asks, data, "asks");
            ApplySide(_bids, data, "bids");
            _lastEventVersion = version;
            _state.LastDepthVersion = version;
        }

        _state.IncDepthUpdates();
        _state.LastDepthUtc = DateTime.UtcNow;
    }

    private static void ApplySide(Dictionary<double, double> side, JsonElement data, string prop)
    {
        if (!data.TryGetProperty(prop, out var arr) || arr.ValueKind != JsonValueKind.Array) return;
        foreach (var lvl in arr.EnumerateArray())
        {
            if (lvl.ValueKind != JsonValueKind.Array) continue;
            var elems = lvl.EnumerateArray().ToArray();
            if (elems.Length < 3) continue;
            if (elems[0].ValueKind != JsonValueKind.Number) continue;
            if (elems[2].ValueKind != JsonValueKind.Number) continue;

            var price = elems[0].GetDouble();
            var qty = elems[2].GetDouble();

            if (qty == 0)
                side.Remove(price);
            else
                side[price] = qty;
        }
    }

    private async Task SyncSnapshotAndCommits(CancellationToken ct)
    {
        // Step 1: full snapshot depth/{symbol} and record version (MEXC docs).
        var snap = await GetDepthSnapshot(ct);

        // Step 3: retrieve depth_commits and merge into local order book (MEXC docs).
        var commits = await GetDepthCommits(ct, limit: 1000);

        // apply snapshot then commits where commit.version > snapshot.version in ascending order
        lock (_bookLock)
        {
            _asks.Clear();
            _bids.Clear();

            foreach (var (price, qty) in snap.asks) _asks[price] = qty;
            foreach (var (price, qty) in snap.bids) _bids[price] = qty;

            var relevant = commits.Where(c => c.version > snap.version).OrderBy(c => c.version).ToList();
            foreach (var c in relevant)
            {
                foreach (var (price, qty) in c.asks) { if (qty == 0) _asks.Remove(price); else _asks[price] = qty; }
                foreach (var (price, qty) in c.bids) { if (qty == 0) _bids.Remove(price); else _bids[price] = qty; }
                _lastEventVersion = c.version;
            }

            if (_lastEventVersion == -1) _lastEventVersion = snap.version;

            _state.LastDepthVersion = _lastEventVersion;
            _state.LastDepthUtc = DateTime.UtcNow;
        }
    }

    private async Task<(long version, List<(double price, double qty)> asks, List<(double price, double qty)> bids)> GetDepthSnapshot(CancellationToken ct)
    {
        // Futures API domain changed to https://api.mexc.com (update log). Use cfg.FuturesRestBaseUrl. (docs)
        var url = $"{_cfg.FuturesRestBaseUrl.TrimEnd('/')}/api/v1/contract/depth/{_cfg.Symbol}";
        using var resp = await _http.GetAsync(url, ct);
        resp.EnsureSuccessStatusCode();

        var json = await resp.Content.ReadAsStringAsync(ct);
        using var doc = JsonDocument.Parse(json);
        var root = doc.RootElement;

        if (!root.TryGetProperty("data", out var data))
            throw new InvalidOperationException("Depth snapshot missing data");

        var version = data.GetProperty("version").GetInt64();
        var asks = ParseDepthArray(data.GetProperty("asks"));
        var bids = ParseDepthArray(data.GetProperty("bids"));
        return (version, asks, bids);
    }

    private async Task<List<(long version, List<(double price, double qty)> asks, List<(double price, double qty)> bids)>> GetDepthCommits(CancellationToken ct, int limit)
    {
        var url = $"{_cfg.FuturesRestBaseUrl.TrimEnd('/')}/api/v1/contract/depth_commits/{_cfg.Symbol}/{limit}";
        using var resp = await _http.GetAsync(url, ct);
        resp.EnsureSuccessStatusCode();

        var json = await resp.Content.ReadAsStringAsync(ct);
        using var doc = JsonDocument.Parse(json);
        var root = doc.RootElement;

        if (!root.TryGetProperty("data", out var data) || data.ValueKind != JsonValueKind.Array)
            return new();

        var list = new List<(long version, List<(double price, double qty)> asks, List<(double price, double qty)> bids)>();
        foreach (var item in data.EnumerateArray())
        {
            if (!item.TryGetProperty("version", out var vEl) || vEl.ValueKind != JsonValueKind.Number) continue;
            var version = vEl.GetInt64();
            var asks = item.TryGetProperty("asks", out var aEl) ? ParseDepthArray(aEl) : new();
            var bids = item.TryGetProperty("bids", out var bEl) ? ParseDepthArray(bEl) : new();
            list.Add((version, asks, bids));
        }
        return list;
    }

    private static List<(double price, double qty)> ParseDepthArray(JsonElement arr)
    {
        var list = new List<(double price, double qty)>();
        if (arr.ValueKind != JsonValueKind.Array) return list;
        foreach (var lvl in arr.EnumerateArray())
        {
            if (lvl.ValueKind != JsonValueKind.Array) continue;
            var elems = lvl.EnumerateArray().ToArray();
            if (elems.Length < 3) continue;
            if (elems[0].ValueKind != JsonValueKind.Number) continue;
            if (elems[2].ValueKind != JsonValueKind.Number) continue;
            list.Add((elems[0].GetDouble(), elems[2].GetDouble()));
        }
        return list;
    }

    private async Task SendJsonAsync(object obj, CancellationToken ct)
    {
        if (_ws == null) return;
        var json = JsonSerializer.Serialize(obj);
        var bytes = Encoding.UTF8.GetBytes(json);
        await _ws.SendAsync(bytes, WebSocketMessageType.Text, endOfMessage: true, ct);
    }

    public (IReadOnlyDictionary<double, double> bids, IReadOnlyDictionary<double, double> asks, long version) SnapshotBook()
    {
        lock (_bookLock)
        {
            return (new Dictionary<double, double>(_bids), new Dictionary<double, double>(_asks), _lastEventVersion);
        }
    }
}
