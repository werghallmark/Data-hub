using System.Security.Claims;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using QuantDesk.DataHub.Common.Config;
using QuantDesk.DataHub.Common.Security;
using QuantDesk.DataHub.Common.Util;
using QuantDesk.DataHub.Service.Connectors;
using QuantDesk.DataHub.Service.Runtime;

// Init-secrets mode: QuantDesk.DataHub.Service.exe --init-secrets "C:\DataHub\secrets.json" "password"
if (args.Length >= 3 && args[0] == "--init-secrets")
{
    var secretsPath = args[1];
    var password = args[2];

    var (hash, salt, iters) = QuantDesk.DataHub.Common.Security.PasswordHasher.Hash(password);
    var secretsObj = new QuantDesk.DataHub.Common.Security.Secrets { PasswordHashB64 = hash, PasswordSaltB64 = salt, Iterations = iters };

    var json = System.Text.Json.JsonSerializer.Serialize(secretsObj, new System.Text.Json.JsonSerializerOptions
    {
        PropertyNamingPolicy = System.Text.Json.JsonNamingPolicy.CamelCase,
        WriteIndented = true
    });

    var dir = System.IO.Path.GetDirectoryName(secretsPath);
    if (!string.IsNullOrWhiteSpace(dir)) System.IO.Directory.CreateDirectory(dir);
    System.IO.File.WriteAllText(secretsPath, json);

    return;
}

var basePath = Environment.GetEnvironmentVariable("DATAHUB_BASE") ?? @"C:\DataHub";
var cfg = ConfigStore.LoadOrCreateDefault(basePath);
var secrets = SecretsStore.LoadOrThrow(basePath);

var builder = WebApplication.CreateBuilder(args);

builder.Logging.AddConsole();

builder.Services.AddSingleton(cfg);
builder.Services.AddSingleton(secrets);
builder.Services.AddSingleton<DataHubState>();

builder.Services.AddSingleton<MexcFuturesCollector>();
builder.Services.AddSingleton<ICollector>(sp => sp.GetRequiredService<MexcFuturesCollector>());
builder.Services.AddSingleton<IBookSource, FuturesBookSource>();

builder.Services.AddSingleton<FrameEngine>();
builder.Services.AddSingleton<RetentionService>();
builder.Services.AddSingleton<DailyRestartService>();
builder.Services.AddHostedService<DataHubHostedService>();

builder.Services
    .AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme)
    .AddCookie(options =>
    {
        options.LoginPath = "/login";
        options.Cookie.Name = "datahub_auth";
        options.Cookie.HttpOnly = true;
        options.Cookie.SameSite = SameSiteMode.Lax;
        options.Cookie.SecurePolicy = CookieSecurePolicy.SameAsRequest;
        options.SlidingExpiration = true;
        options.ExpireTimeSpan = TimeSpan.FromHours(12);
    });

builder.Services.AddAuthorization();

builder.WebHost.ConfigureKestrel(k =>
{
    k.Listen(System.Net.IPAddress.Parse(cfg.BindIp), cfg.MainPort);
    k.Listen(System.Net.IPAddress.Parse(cfg.BindIp), cfg.FramePort);
});

var app = builder.Build();

app.Use(async (ctx, next) =>
{
    // Port separation requirement: only frame routes on FramePort.
    if (ctx.Connection.LocalPort == cfg.FramePort)
    {
        var p = ctx.Request.Path.Value ?? "";
        if (!p.StartsWith("/frame", StringComparison.OrdinalIgnoreCase))
        {
            ctx.Response.StatusCode = 404;
            await ctx.Response.WriteAsync("Not found.");
            return;
        }
    }
    await next();
});

app.UseAuthentication();
app.UseAuthorization();

app.MapGet("/", async ctx =>
{
    ctx.Response.ContentType = "text/html; charset=utf-8";
    await ctx.Response.WriteAsync("<!doctype html><html><head><meta charset='utf-8'><title>QuantDesk DataHub</title></head>" +
        "<body style='font-family:Segoe UI, Arial; padding:20px;'>" +
        "<h2>QuantDesk DataHub</h2>" +
        "<ul><li><a href='/ui'>Web Control Panel</a></li>" +
        "<li><code>/frame/latest</code> (Frame API on port 8010)</li></ul></body></html>");
});

app.MapGet("/login", async ctx =>
{
    ctx.Response.ContentType = "text/html; charset=utf-8";
    await ctx.Response.WriteAsync("<!doctype html><html><head><meta charset='utf-8'><title>Login</title></head>" +
        "<body style='font-family:Segoe UI, Arial; padding:20px;'>" +
        "<h3>Login</h3>" +
        "<form method='post' action='/login'>" +
        "<label>Password:</label><br/>" +
        "<input type='password' name='password' style='width:280px; padding:8px;'/><br/><br/>" +
        "<button type='submit' style='padding:8px 14px;'>Sign in</button>" +
        "</form></body></html>");
});

app.MapPost("/login", async ctx =>
{
    var form = await ctx.Request.ReadFormAsync();
    var password = form["password"].ToString();

    if (string.IsNullOrWhiteSpace(password))
    {
        ctx.Response.Redirect("/login");
        return;
    }

    var ok = PasswordHasher.Verify(password, secrets.PasswordHashB64, secrets.PasswordSaltB64, secrets.Iterations);
    if (!ok)
    {
        ctx.Response.StatusCode = 401;
        await ctx.Response.WriteAsync("Invalid password.");
        return;
    }

    var claims = new[] { new Claim(ClaimTypes.Name, "admin") };
    var identity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);
    await ctx.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, new ClaimsPrincipal(identity));

    ctx.Response.Redirect("/ui");
});

app.MapGet("/ui", async ctx =>
{
    if (!ctx.User.Identity?.IsAuthenticated ?? true)
    {
        ctx.Response.Redirect("/login");
        return;
    }

    ctx.Response.ContentType = "text/html; charset=utf-8";
    await ctx.Response.WriteAsync("<!doctype html><html><head><meta charset='utf-8'><title>DataHub Control</title></head>" +
        "<body style='font-family:Segoe UI, Arial; padding:20px;'>" +
        "<h2>DataHub Control Panel</h2>" +
        "<div id='status' style='white-space:pre; background:#f3f3f3; padding:12px; border-radius:8px;'></div><br/>" +
        "<button onclick=\"callApi('/api/collector/restart')\" style='padding:8px 14px;'>Restart Collector</button>" +
        "<button onclick=\"callApi('/api/collector/stop')\" style='padding:8px 14px; margin-left:6px;'>Stop Collector</button>" +
        "<button onclick=\"callApi('/api/collector/start')\" style='padding:8px 14px; margin-left:6px;'>Start Collector</button>" +
        "<br/><br/><h3>Errors (tail)</h3>" +
        "<pre id='errors' style='background:#0b0b0b; color:#e6e6e6; padding:12px; border-radius:8px; max-height:260px; overflow:auto;'></pre>" +
        "<script>" +
        "async function refresh(){ const s = await fetch('/api/status'); document.getElementById('status').innerText = JSON.stringify(await s.json(), null, 2);" +
        "const e = await fetch('/api/errors?tail=50'); document.getElementById('errors').innerText = (await e.text()); }" +
        "async function callApi(path){ await fetch(path, {method:'POST'}); await refresh(); }" +
        "setInterval(refresh, 1000); refresh();" +
        "</script></body></html>");
}).RequireAuthorization();

app.MapGet("/api/status", (AppConfig cfg, DataHubState st) =>
{
    return Results.Json(new
    {
        tsUtc = DateTime.UtcNow.ToString("O"),
        exchange = cfg.Exchange,
        market = cfg.Market,
        symbol = cfg.Symbol,
        bindIp = cfg.BindIp,
        ports = new { main = cfg.MainPort, frame = cfg.FramePort },
        collector = new
        {
            running = st.CollectorRunning,
            status = st.CollectorStatus,
            lastDepthUtc = st.LastDepthUtc == DateTime.MinValue ? null : st.LastDepthUtc.ToString("O"),
            lastTradeUtc = st.LastTradeUtc == DateTime.MinValue ? null : st.LastTradeUtc.ToString("O"),
            lastDepthVersion = st.LastDepthVersion,
            depthUpdates = st.DepthUpdates,
            trades = st.Trades
        },
        frames = new
        {
            lastFrameUtc = st.LastFrameUtc == DateTime.MinValue ? null : st.LastFrameUtc.ToString("O"),
            framesWritten = st.FramesWritten
        }
    });
}).RequireAuthorization();

app.MapGet("/api/errors", (AppConfig cfg, HttpRequest req) =>
{
    if (!int.TryParse(req.Query["tail"], out var tail)) tail = 50;
    tail = Math.Clamp(tail, 1, 500);
    var lines = ErrorLedger.Tail(cfg.BasePath, tail);
    return Results.Text(string.Join("\n", lines), "text/plain; charset=utf-8");
}).RequireAuthorization();

app.MapPost("/api/collector/restart", async (ICollector collector, HttpContext ctx) =>
{
    await collector.RestartAsync(ctx.RequestAborted);
    return Results.Ok();
}).RequireAuthorization();

app.MapPost("/api/collector/stop", async (ICollector collector) =>
{
    await collector.StopAsync();
    return Results.Ok();
}).RequireAuthorization();

app.MapPost("/api/collector/start", async (ICollector collector, HttpContext ctx) =>
{
    await collector.StartAsync(ctx.RequestAborted);
    return Results.Ok();
}).RequireAuthorization();

app.MapGet("/frame/latest", (DataHubState st) =>
{
    if (string.IsNullOrWhiteSpace(st.LastFrameJson)) return Results.Text("{}", "application/json");
    return Results.Text(st.LastFrameJson, "application/json");
});

app.Run();
