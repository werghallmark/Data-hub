# QuantDesk DataHub Manual (v1.0)

## What you get
- **Background service**: `QuantDesk.DataHub.Service.exe` (self-contained)  
  - Collects MEXC Futures L2 (depth + trades) for the selected symbol
  - Stores raw feed as **gzip JSONL rotated by UTC hour**
  - Maintains a live in-memory order book using MEXC version continuity + REST recovery
  - Writes **200ms frames** as gzip JSONL rotated by UTC hour
  - Web control panel on port **8000** (password login)
  - Frame API on port **8010** (`/frame/latest`)

- **Desktop Control Panel**: `QuantDesk.DataHub.ControlPanel.exe`
  - Requires master password to open
  - One-click open of Web Control + Frame API URLs

## Install (recommended)
1) Build the binaries
- Open **CMD as Administrator**
- Run:
  - `build.cmd`

2) Build the installer (optional, but recommended)
- Install Inno Setup 6 (standard Windows installer builder)
- If `where ISCC` returns a path, you can build the installer with:
  - `ISCC installer\DataHub.iss`
- Or run the default install location explicitly:
  - `"C:\Program Files (x86)\Inno Setup 6\ISCC.exe" installer\DataHub.iss`

3) Run installer EXE
- Set master password (twice)
- Choose market/symbol
- Installer will:
  - Create `C:\DataHub\config.json` and `C:\DataHub\secrets.json`
  - Create firewall rules for 8000/8010 restricted to Tailscale 100.64.0.0/10
  - Disable sleep/hibernate on AC + lid close do nothing on AC
  - Create scheduled tasks:
    - `QuantDeskDataHub` (SYSTEM, on boot)
    - `QuantDeskDataHub_ControlPanel` (on logon)
  - Start the service immediately

## URLs (Tailscale)
- Web Control: `http://<tailscale-ip>:8000/ui`
- Frame API: `http://<tailscale-ip>:8010/frame/latest`

## Uninstall
- Use Windows “Apps & Features” uninstall.
- It removes scheduled tasks + firewall rules.
- Data in `C:\DataHub` is not deleted automatically (you can delete manually).

## Notes / current limits
- This v1.0 build implements **MEXC Futures** collector end-to-end (snapshot + depth_commits recovery + WS updates).
- A Spot connector is planned (requires protobuf message decoding). The build includes a proto-fetch step in `tools\fetch_protos.cmd` for future extension.
