# Sources used for this build (public docs)

- MEXC Futures WebSocket API (edge): `wss://contract.mexc.com/edge` and `sub.depth` / `sub.deal` channels, ping/pong, and the incremental order book maintenance mechanism (version continuity + recovery steps).
- MEXC Futures REST market data: `/api/v1/contract/depth/{symbol}` and `/api/v1/contract/depth_commits/{symbol}/{limit}`.
- MEXC Futures API domain change notice: move to `https://api.mexc.com` (effective Jan 19, 2026).

(See citations in the ChatGPT response for the exact URLs.)
