# QuantDesk DataHub v1.0 (Windows 10+)

This bundle contains the full source + installer script for the QuantDesk DataHub contract.

Build steps: run `build.cmd` from an **Administrator Command Prompt**.
